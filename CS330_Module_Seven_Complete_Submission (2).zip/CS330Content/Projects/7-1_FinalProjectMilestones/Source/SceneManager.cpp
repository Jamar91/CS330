///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize every texture slot before any images are loaded.
	m_loadedTextures = 0;
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "";
		m_textureIDs[i].ID = 0;
	}
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads each square image once and associates it with a
 *  descriptive tag used by the individual airplane shapes.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	CreateGLTexture("textures/airfield.png", "airfield");
	CreateGLTexture("textures/aircraft_metal.png", "aircraftMetal");
	CreateGLTexture("textures/red_paint.png", "redPaint");
	CreateGLTexture("textures/canopy_glass.png", "canopyGlass");

	// Texture images must be bound before the first render pass.
	BindGLTextures();
}



/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines material properties for the runway, painted metal,
 *  aircraft metal, and canopy.  These values control the
 *  diffuse and specular portions of the Phong lighting model.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    OBJECT_MATERIAL material;

    material.diffuseColor = glm::vec3(0.75f, 0.75f, 0.75f);
    material.specularColor = glm::vec3(0.12f, 0.12f, 0.12f);
    material.shininess = 8.0f;
    material.tag = "runway";
    m_objectMaterials.push_back(material);

    material.diffuseColor = glm::vec3(0.85f, 0.85f, 0.88f);
    material.specularColor = glm::vec3(0.75f, 0.75f, 0.78f);
    material.shininess = 48.0f;
    material.tag = "aircraftMetal";
    m_objectMaterials.push_back(material);

    material.diffuseColor = glm::vec3(0.90f, 0.45f, 0.45f);
    material.specularColor = glm::vec3(0.55f, 0.35f, 0.35f);
    material.shininess = 32.0f;
    material.tag = "paintedMetal";
    m_objectMaterials.push_back(material);

    material.diffuseColor = glm::vec3(0.45f, 0.60f, 0.70f);
    material.specularColor = glm::vec3(0.95f, 0.95f, 1.0f);
    material.shininess = 72.0f;
    material.tag = "canopy";
    m_objectMaterials.push_back(material);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Uses a bright directional light as daylight and a softer
 *  point light as fill.  The fill light keeps the shaded side
 *  of the airplane readable without flattening the scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    if (NULL == m_pShaderManager)
        return;

    // Enable Phong lighting for all subsequently rendered objects.
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Primary daylight: white light coming from above and camera-left.
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);
    m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.45f, -1.0f, -0.35f));
    m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.24f, 0.24f, 0.26f));
    m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.78f, 0.78f, 0.74f));
    m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.70f, 0.70f, 0.70f));

    // Secondary fill light: subtle cool tint from the opposite side.
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
    m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-4.0f, 6.0f, 5.0f));
    m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.04f, 0.05f, 0.08f));
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.20f, 0.28f, 0.42f));
    m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.22f, 0.30f, 0.45f));

    // Explicitly disable unused lights so the lighting state is predictable.
    for (int i = 1; i < 5; ++i)
    {
        std::string lightName = "pointLights[" + std::to_string(i) + "].bActive";
        m_pShaderManager->setBoolValue(lightName, false);
    }
    m_pShaderManager->setBoolValue("spotLight.bActive", false);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load textures, define Phong materials, and configure scene lighting.
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// Load each primitive once. These meshes are reused to build the airplane.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadBoxMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  Milestone scene: airplane built from a cylinder, cone,
 *  and several transformed boxes positioned over a plane.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Ground plane uses a tiled airfield texture. Repeating the square image
	// provides extra detail across the large surface without visible stretching.
	scaleXYZ = glm::vec3(20.0f, 1.0f, 12.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("airfield");
	SetShaderMaterial("runway");
	SetTextureUVScale(10.0f, 6.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Fuselage: rotate the cylinder so its long axis runs front-to-back.
	scaleXYZ = glm::vec3(0.75f, 4.0f, 0.75f);
	positionXYZ = glm::vec3(0.0f, 2.25f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -90.0f, positionXYZ);
	SetShaderTexture("aircraftMetal");
	SetShaderMaterial("aircraftMetal");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Nose: cone attached to the front of the fuselage.
	scaleXYZ = glm::vec3(0.78f, 1.25f, 0.78f);
	positionXYZ = glm::vec3(4.55f, 2.25f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -90.0f, positionXYZ);
	SetShaderTexture("redPaint");
	SetShaderMaterial("paintedMetal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawConeMesh();

	// Main wing: a wide, thin box crossing the center of the fuselage.
	scaleXYZ = glm::vec3(2.2f, 0.18f, 8.0f);
	positionXYZ = glm::vec3(0.2f, 2.20f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, -8.0f, 0.0f, positionXYZ);
	SetShaderTexture("aircraftMetal");
	SetShaderMaterial("aircraftMetal");
	SetTextureUVScale(3.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// Horizontal tail plane: smaller than the main wing and placed at the rear.
	scaleXYZ = glm::vec3(1.25f, 0.14f, 3.4f);
	positionXYZ = glm::vec3(-3.25f, 2.38f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("aircraftMetal");
	SetShaderMaterial("aircraftMetal");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Vertical stabilizer: thin upright box at the back of the airplane.
	scaleXYZ = glm::vec3(1.15f, 1.35f, 0.16f);
	positionXYZ = glm::vec3(-3.25f, 3.15f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -12.0f, positionXYZ);
	SetShaderTexture("redPaint");
	SetShaderMaterial("paintedMetal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Cockpit/canopy: a box above the forward fuselage adds recognizable detail.
	scaleXYZ = glm::vec3(1.25f, 0.42f, 0.72f);
	positionXYZ = glm::vec3(1.55f, 2.85f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("canopyGlass");
	SetShaderMaterial("canopy");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

    // Cargo crate: a separate box object parked beside the aircraft.
    scaleXYZ = glm::vec3(1.5f, 1.3f, 1.5f);
    positionXYZ = glm::vec3(-1.7f, 0.68f, 4.5f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderTexture("redPaint");
    SetShaderMaterial("paintedMetal");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // Three safety cones: reuse the same low-polygon cone mesh.
    for (int i = 0; i < 3; ++i)
    {
        scaleXYZ = glm::vec3(0.38f, 0.95f, 0.38f);
        positionXYZ = glm::vec3(-5.0f + i * 3.0f, 0.48f, -4.6f);
        SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
        SetShaderTexture("redPaint");
        SetShaderMaterial("paintedMetal");
        SetTextureUVScale(1.0f, 1.0f);
        m_basicMeshes->DrawConeMesh();
    }

}
